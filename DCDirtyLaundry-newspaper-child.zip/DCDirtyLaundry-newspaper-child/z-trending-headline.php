<?php
$args = array('post_type' => 'post', 'range' => 'daily', 'limit' => 1);
$popular_posts = new WPP_Query( $args );
if ( !empty($popular_posts->get_posts()) ) {
	if ( get_the_ID() == $popular_posts->get_posts()[0]->id ) {
		$args2 = array( 'numberposts' => '1', 'post_status' => 'publish,' );
		$recent_posts = wp_get_recent_posts( $args2 );
		foreach( $recent_posts as $recent ){
			echo '<p class="latestarticle-'. get_the_ID() . '"><strong>Latest: </strong><a href="' . get_permalink($recent["ID"]) . '"><span class=\'latest-title\'>' .   $recent["post_title"].'</span></a></p>';
		}
		wp_reset_query();
    }
	else {
		wpp_get_mostpopular( 'post_type=post&range=daily&limit=1&order_by="avg"&wpp_start="<p>"&wpp_end="</p>"&post_html="<strong>Trending: </strong><a href=\'{url}\' class=\'mostpopular-{pid}\'><span class=\'mostpopular-title\'>{text_title}</span></a>"' ) ;
    }
}
?>
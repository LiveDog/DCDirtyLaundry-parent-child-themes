<div class="z-ad-revcontent-engagefeed">
<div id="rcjsload_be71b5"></div>
<script type="text/javascript">
(function() {
var meta=document.head.querySelector("meta[name='keywords']"),k=!1;meta&&(k=meta.content),k||(meta=document.head.querySelector("meta[property='og:title']"))&&(k=meta.content),k||(meta=document.head.querySelector("meta[property='title']"))&&(k=meta.content),k=k?encodeURI(k):"";
var sParameterName,i,sPageURL=decodeURIComponent(window.location.search.substring(1)),sURLVariables=sPageURL.split("&"),page_utms="";for(i=0;i<sURLVariables.length;i++)"utm_"==(sParameterName=sURLVariables[i].split("="))[0].substr(0,4)&&(page_utms+=sParameterName[0]+"="+sParameterName[1]+"&");
var docReady = function(fn) {
    if (document.readyState != 'loading') {fn(); } else if (document.addEventListener) {document.addEventListener('DOMContentLoaded', fn); } else {document.attachEvent('onreadystatechange', function() {if (document.readyState != 'loading') fn(); }); }
}(function() {
var referer="";try{if(referer=document.referrer,"undefined"==typeof referer||""==referer)throw"undefined"}catch(exception){referer=document.location.href,(""==referer||"undefined"==typeof referer)&&(referer=document.URL)}referer=referer.substr(0,700);
var rcds = document.getElementById("rcjsload_be71b5");
var rcel = document.createElement("script");
rcel.id = 'rc_' + Math.floor(Math.random() * 1000);
rcel.type = 'text/javascript';
rcel.src = "//feed.engage.im/feed.js.php?w=105603&t="+rcel.id+"&c="+(new Date()).getTime()+"&width="+(window.outerWidth || document.documentElement.clientWidth)+"&referer="+encodeURIComponent(referer)+'&container_width='+rcds.offsetWidth+"&k="+k+"&page_utms="+encodeURIComponent(page_utms);
rcel.async = true;
rcds.appendChild(rcel);
});
})();
</script>
</div>
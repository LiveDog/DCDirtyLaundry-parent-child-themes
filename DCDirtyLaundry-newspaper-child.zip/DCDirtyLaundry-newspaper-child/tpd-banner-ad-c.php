<?php /*?><div class="tpd-banner-ad-c">
    <div id='tpd-banner-ad-c'>   
		<script type='text/javascript'>
        if (TPD_Mobile == false) {
        googletag.cmd.push( function() {
        googletag.display( 'tpd-banner-ad-c' );
        } );
        }
        </script>
    </div>
</div><?php */?>
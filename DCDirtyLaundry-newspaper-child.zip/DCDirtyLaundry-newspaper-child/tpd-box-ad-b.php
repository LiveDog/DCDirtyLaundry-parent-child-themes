<div class='tpd-box-ad-b'>
	<div id='tpd-box-ad-b'>   
		<script type='text/javascript'>
		googletag.cmd.push( function() {
		googletag.display( 'tpd-box-ad-b' );
		});
		</script>
	</div>
</div>
<div class="trending-post">
<h2 class="widget-title related-content-title" style="overflow: visible;margin:20px 0;"><span>Trending Now on <?php bloginfo( 'name' ); ?></span></h2>
<?php wpp_get_mostpopular( 'thumbnail_width=300&range=daily&thumbnail_height=130&limit=3&order_by="avg"&post_html="<li>{thumb}<h3>{title}</h3></li>"' ); ?>
</div>
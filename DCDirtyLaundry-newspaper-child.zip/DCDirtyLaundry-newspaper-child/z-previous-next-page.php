<?php $args = array(
'before'           => '<p class="blur-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat cupidatat non proident.</p><div class="single-prev-next-page">',
'after'            => '<br clear="all"></div>',
'link_before'      => '',
'link_after'       => '',
'next_or_number'   => 'next',
'previouspagelink' => __('<span class="multi-back">← Back To Previous Page</span>'),
'nextpagelink'     => __('<span class="multi-next-page">CONTINUE READING  ⌄</span><style>.blur-text {display:block!important;}</style>'),
'pagelink'         => '%',
'echo'             => 1 ); 
wp_link_pages( $args ); ?>
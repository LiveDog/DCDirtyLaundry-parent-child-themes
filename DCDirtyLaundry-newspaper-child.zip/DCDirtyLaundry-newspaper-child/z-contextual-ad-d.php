<div class="z-contextual-ad-d">
	<div id='tpd-contextual-ad-d'>
		<div id="taboola-below-article-thumbnails-feed"></div>
		<script type="text/javascript">
		window._taboola = window._taboola || [];
		_taboola.push({
				device: TPD_ContextualAd_D_Tab_device,
				mode: TPD_ContextualAd_D_Tab_mode,
				container: TPD_ContextualAd_D_Tab_container,
				placement: TPD_ContextualAd_D_Tab_placement,
				target_type: TPD_ContextualAd_D_Tab_targettype
		});
		</script>
	</div>
</div>
<div class="z-contextual-ad-a">
    <div id='tpd-contextual-ad-a'>
    <div id="taboola-below-article-thumbnails"></div>
		<script type="text/javascript">
        window._taboola = window._taboola || [];
        _taboola.push({
                device: TPD_ContextualAd_A_Tab_device,
                mode: TPD_ContextualAd_A_Tab_mode,
                container: TPD_ContextualAd_A_Tab_container,
                placement: TPD_ContextualAd_A_Tab_placement,
                target_type: TPD_ContextualAd_A_Tab_targettype
        });
        </script>
    </div>
</div>
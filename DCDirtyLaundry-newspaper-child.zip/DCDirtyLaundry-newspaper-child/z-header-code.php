<meta name="robots" content="noimageindex">
<meta name="googlebot" content="noimageindex">
<meta name="viewport" content="initial-scale=1,maximum-scale=1,user-scalable=no" />

<script id="mcjs">!function(c,h,i,m,p){m=c.createElement(h),p=c.getElementsByTagName(h)[0],m.async=1,m.src=i,p.parentNode.insertBefore(m,p)}(document,"script","https://chimpstatic.com/mcjs-connected/js/users/d5e840729179eebb74070369f/73091cb426cd50aacd8c5c00d.js");</script>

<!-- START NEW TAB BACK BUTTON HIJACK -->
<link rel="prerender" href="<?php echo get_site_url(); ?>" />
<script type="text/javascript">
jQuery(document).ready(function(){1==history.length&&function(t,e){history.replaceState(null,document.title,e.pathname+"#!/back"),history.pushState(null,document.title,e.pathname),t.addEventListener("popstate",function(){"#!/back"===e.hash&&(history.replaceState(null,document.title,e.pathname),setTimeout(function(){e.replace("<?php echo get_bloginfo('url'); ?>")},0))},!1)}(window,location)});
</script>
<!-- END NEW TAB BACK BUTTON HIJACK -->

<?php if (is_single() || is_category() || is_archive() ) { ?>

<script data-cfasync="false" type="text/javascript">(function(s,o,l,v,e,d){if(s[o]==null&&s[l+e]){s[o]="loading";s[l+e](d,l=function(){s[o]="complete";s[v+e](d,l,!1)},!1)}})(document,"readyState","add","remove","EventListener","DOMContentLoaded");(function(){var s=document.createElement("script");s.type="text/javascript";s.async=true;s.src="//cdn.seaofads.com/Scripts/infinity.js.aspx?guid=f507e734-3685-4539-bda1-039e663a1fec";s.id="infinity";s.setAttribute("data-guid","f507e734-3685-4539-bda1-039e663a1fec");s.setAttribute("data-version","async");var e=document.getElementsByTagName('script')[0];e.parentNode.insertBefore(s,e)})();</script>

<!-- START PD PRELOAD/PREFETCH CODE -->
<link rel='dns-prefetch' href='//fastlane.rubiconproject.com'>
<link rel='dns-prefetch' href='//optimized-by.rubiconproject.com'>
<!-- END PD PRELOAD/PREFETCH CODE -->

<!-- START AdSense JS code -->
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- END AdSense JS code -->

<!-- START PubDesk Ad CODE -->
<script src="//s.206ads.com/configs/dcdirtylaundry.com.js"></script>
<script async="async" src="//www.googletagservices.com/tag/js/gpt.js"></script>
<script>
var bannerAd_A;
var bannerAd_B;
var boxAd_A;
var boxAd_B;
var boxAd_C;
var boxAd_D;
var boxAd_E;
var boxAd_F;
var nativeAd_A;
var oopAd_A;	
var oopAd_B;	
var TPD_Mobile;
googletag.cmd.push(function () {
if (TPD_Mobile == false) {
//desktop specific slots
bannerAd_A = googletag.defineSlot(TPD_AdUnit, prebidLeaderboard, 'tpd-banner-ad-a').addService(googletag.pubads()).setTargeting("position", pos_bannerAdA).setTargeting("refreshcount", TPD_BannerA_refresh).setTargeting("refresh", 'false');
bannerAd_B = googletag.defineSlot(TPD_AdUnit, prebidLeaderboard_B, 'tpd-banner-ad-b').addService(googletag.pubads()).setTargeting("position", pos_bannerAdB).setTargeting("refreshcount", TPD_BannerB_refresh).setTargeting("refresh", 'false');
boxAd_A = googletag.defineSlot(TPD_AdUnit, prebidBoxAd_A, 'tpd-box-ad-a').addService(googletag.pubads()).setTargeting("position", pos_boxAdA).setTargeting("refreshcount", TPD_BoxA_refresh).setTargeting("refresh", 'false');
boxAd_B = googletag.defineSlot(TPD_AdUnit, prebidBoxAd_B, 'tpd-box-ad-b').addService(googletag.pubads()).setTargeting("position", pos_boxAdB).setTargeting("refreshcount", TPD_BoxB_refresh).setTargeting("refresh", 'false');
boxAd_C = googletag.defineSlot(TPD_AdUnit, prebidBoxAd_C, 'tpd-box-ad-c').addService(googletag.pubads()).setTargeting("position", pos_boxAdC).setTargeting("refreshcount", TPD_BoxC_refresh).setTargeting("refresh", 'false');
boxAd_D = googletag.defineSlot(TPD_AdUnit, prebidBoxAd_D, 'tpd-box-ad-d').addService(googletag.pubads()).setTargeting("position", pos_boxAdD).setTargeting("refreshcount", TPD_BoxD_refresh).setTargeting("refresh", 'false');
boxAd_E = googletag.defineSlot(TPD_AdUnit, prebidBoxAd_E, 'tpd-box-ad-e').addService(googletag.pubads()).setTargeting("position", pos_boxAdE).setTargeting("refreshcount", TPD_BoxE_refresh).setTargeting("refresh", 'false');
boxAd_F = googletag.defineSlot(TPD_AdUnit, prebidBoxAd_F, 'tpd-box-ad-f').addService(googletag.pubads()).setTargeting("position", pos_boxAdF).setTargeting("refreshcount", TPD_BoxF_refresh).setTargeting("refresh", 'false');
nativeAd_A = googletag.defineSlot(TPD_AdUnit_Native_A, prebidNativeAd_A, 'tpd-native-ad-a').addService(googletag.pubads()).setTargeting("position", pos_nativeAdA).setTargeting("refresh", 'false').setCollapseEmptyDiv(true);
oopAd_A = googletag.defineSlot(TPD_AdUnit_OOP, prebidOOPAd_A, 'tpd-oop-ad-a').addService(googletag.pubads()).setTargeting("refresh", 'false').setTargeting("position", pos_oopAdA).setCollapseEmptyDiv(true);
oopAd_B = googletag.defineSlot(TPD_AdUnit_OOP, prebidOOPAd_B, 'tpd-oop-ad-b').addService(googletag.pubads()).setTargeting("refresh", 'false').setTargeting("position", pos_oopAdB).setCollapseEmptyDiv(true);
} else if (TPD_Mobile == true) {
//mob specific slots
bannerAd_A = googletag.defineSlot(TPD_AdUnit, prebidLeaderboard, 'tpd-banner-ad-a').addService(googletag.pubads()).setTargeting("position", pos_bannerAdA).setTargeting("refreshcount", TPD_BannerA_refresh).setTargeting("refresh", 'false');
boxAd_A = googletag.defineSlot(TPD_AdUnit, prebidBoxAd_A, 'tpd-box-ad-a').addService(googletag.pubads()).setTargeting("position", pos_boxAdA).setTargeting("refreshcount", TPD_BoxA_refresh).setTargeting("refresh", 'false');
boxAd_B = googletag.defineSlot(TPD_AdUnit, prebidBoxAd_B, 'tpd-box-ad-b').addService(googletag.pubads()).setTargeting("position", pos_boxAdB).setTargeting("refreshcount", TPD_BoxB_refresh).setTargeting("refresh", 'false');
boxAd_C = googletag.defineSlot(TPD_AdUnit, prebidBoxAd_C, 'tpd-box-ad-c').addService(googletag.pubads()).setTargeting("position", pos_boxAdC).setTargeting("refreshcount", TPD_BoxC_refresh).setTargeting("refresh", 'false');
boxAd_D = googletag.defineSlot(TPD_AdUnit, prebidBoxAd_D, 'tpd-box-ad-d').addService(googletag.pubads()).setTargeting("position", pos_boxAdD).setTargeting("refreshcount", TPD_BoxD_refresh).setTargeting("refresh", 'false');
boxAd_E = googletag.defineSlot(TPD_AdUnit, prebidBoxAd_E, 'tpd-box-ad-e').addService(googletag.pubads()).setTargeting("position", pos_boxAdE).setTargeting("refreshcount", TPD_BoxE_refresh).setTargeting("refresh", 'false');
boxAd_F = googletag.defineSlot(TPD_AdUnit, prebidBoxAd_F, 'tpd-box-ad-f').addService(googletag.pubads()).setTargeting("position", pos_boxAdF).setTargeting("refreshcount", TPD_BoxF_refresh).setTargeting("refresh", 'false');
nativeAd_A = googletag.defineSlot(TPD_AdUnit_Native_A, prebidNativeAd_A, 'tpd-native-ad-a').addService(googletag.pubads()).setTargeting("position", pos_nativeAdA).setTargeting("refresh", 'false').setCollapseEmptyDiv(true);
oopAd_A = googletag.defineSlot(TPD_AdUnit_OOP, prebidOOPAd_A, 'tpd-oop-ad-a').addService(googletag.pubads()).setTargeting("refresh", 'false').setTargeting("position", pos_oopAdA).setCollapseEmptyDiv(true);
oopAd_B = googletag.defineSlot(TPD_AdUnit_OOP, prebidOOPAd_B, 'tpd-oop-ad-b').addService(googletag.pubads()).setTargeting("refresh", 'false').setTargeting("position", pos_oopAdB).setCollapseEmptyDiv(true);
}
googletag.pubads().setTargeting("Domain", TPD_Domain);
googletag.pubads().setTargeting("Path", TPD_Path);
googletag.pubads().setTargeting("URL", TPD_URL);
googletag.pubads().setTargeting("Testmode", TPD_Testmode);
googletag.pubads().setTargeting("kw", TPD_TitleKW);

//TO BE POPULATED BY THE DEV TEAM
googletag.pubads().setTargeting('PostID', ['<?php echo get_the_ID(); ?>']);
googletag.pubads().setTargeting('Page-Type', ['<?php if ( is_front_page() || is_home() ) { echo 'front-page'; } elseif ( is_single() ) { echo 'single'; } else { echo 'archive'; } ?>']);
googletag.pubads().setTargeting('Post-Type', ['<?php echo get_post_type( $post->ID ); ?>']);
googletag.pubads().setTargeting('Post-Author', ["<?php echo get_the_author_meta('display_name', $author_id); ?>"]);
googletag.pubads().setTargeting('Category', ['<?php $categories = get_the_category(); if ( ! empty( $categories ) ) { echo esc_html( $categories[0]->name ); } ?>']);
// END OF SECTION WHERE EDITS ARE NEEDED

googletag.pubads().enableSingleRequest();
googletag.enableServices();
});
</script>
<!-- END PubDesk Ad CODE -->

<div id='tpd-oop-ad-a'>   
<script type='text/javascript'>
googletag.cmd.push( function() {
googletag.display( 'tpd-oop-ad-a' );
} );
</script></div>

<div id='tpd-oop-ad-b'>   
<script type='text/javascript'>
googletag.cmd.push( function() {
googletag.display( 'tpd-oop-ad-b' );
} );
</script></div>

<?php get_template_part( 'tpd-banner-ad-a' ); ?>

<?php } ?>

<!-- START ANALYTICS CODE -->
<?php
$this_post = get_queried_object();
$author_id = $this_post->post_author;
?>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-53014754-33', 'auto'); // Site's UA code
  <?php if(is_single()) { ?>
  ga('set', 'dimension1', "<?php echo get_the_author_meta('display_name', $author_id); ?>");
  <?php } ?>
  ga('send', 'pageview');
</script>
<!-- END ANALYTICS CODE -->

<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri() .'/z-custom.css"'; ?> media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri() .'/z-custom-media-queries.css"'; ?> media="all" />

<!-- Begin comScore Tag -->
<script>
  var _comscore = _comscore || [];
  _comscore.push({ c1: "2", c2: "22315475" });
  (function() {
    var s = document.createElement("script"), el = document.getElementsByTagName("script")[0]; s.async = true;
    s.src = (document.location.protocol == "https:" ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js";
    el.parentNode.insertBefore(s, el);
  })();
</script>
<noscript>
  <img src="http://b.scorecardresearch.com/p?c1=2&c2=22315475&cv=2.0&cj=1" />
</noscript>
<!-- End comScore Tag -->

<!-- Begin AdSupply Tag -->
<script data-cfasync="false" type="text/javascript">(function(s,o,l,v,e,d){if(s[o]==null&&s[l+e]){s[o]="loading";s[l+e](d,l=function(){s[o]="complete";s[v+e](d,l,!1)},!1)}})(document,"readyState","add","remove","EventListener","DOMContentLoaded");(function(){var s=document.createElement("script");s.type="text/javascript";s.async=true;s.src="//cdn.engine.4dsply.com/Scripts/infinity.js.aspx?guid=f507e734-3685-4539-bda1-039e663a1fec";s.id="infinity";s.setAttribute("data-guid","f507e734-3685-4539-bda1-039e663a1fec");s.setAttribute("data-version","async");var e=document.getElementsByTagName('script')[0];e.parentNode.insertBefore(s,e)})();</script>
<!-- End AdSupply Tag -->

<!-- START Quantcast Tag, part 1 of 2 -->
<script type="text/javascript">
    var _qevents = _qevents || [];
    (function() {
        var elem = document.createElement('script');
        elem.src = (document.location.protocol == "https:" ? "https://secure" : "http://edge")
                    + ".quantserve.com/quant.js";
        elem.async = true;
        elem.type = "text/javascript";
        var scpt = document.getElementsByTagName('script')[0];
        scpt.parentNode.insertBefore(elem, scpt);
    })();
</script>
<!-- END Quantcast Tag, part 1 of 2 -->

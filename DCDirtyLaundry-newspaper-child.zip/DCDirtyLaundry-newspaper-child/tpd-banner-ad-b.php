<?php /*?><div class="tpd-banner-ad-b">
    <div id='tpd-banner-ad-b'>   
		<script type='text/javascript'>
        if (TPD_Mobile == false) {
        googletag.cmd.push( function() {
        googletag.display( 'tpd-banner-ad-b' );
        } );
        }
        </script>
    </div>
</div><?php */?>
<div id="powr_1"></div> 
<script src="//player.powr.com/powr.min.js?v=1"></script>
<script type="text/javascript">
  (function() { 
      var title = document.head.querySelector("meta[property='og:title']");
      var keywords = document.head.querySelector("meta[name=keywords]");
      var term = "";
      if (title) { 
              term = title.content; 
      } else if (keywords) { 
              term = keywords.content; 
      }
      new PowrPlayer({
         "user_id": 10005472,
         "domain": "dcdirtylaundry.com",
         "placeholder": "powr_1",
         "term": term,
         "autoplay": true
      });
  })(); 
</script>
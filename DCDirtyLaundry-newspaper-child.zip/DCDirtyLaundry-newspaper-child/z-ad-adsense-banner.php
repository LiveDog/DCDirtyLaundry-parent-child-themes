<div class="tpd-banner-ad-b">
	<!-- dcDirtyLaundry.com-responsive-1 -->
	<ins class="adsbygoogle"
		 style="display:block"
		 data-ad-client="ca-pub-3121246872096424"
		 data-ad-slot="5884050565"
		 data-ad-format="auto"></ins>
	<script>
	(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
</div>
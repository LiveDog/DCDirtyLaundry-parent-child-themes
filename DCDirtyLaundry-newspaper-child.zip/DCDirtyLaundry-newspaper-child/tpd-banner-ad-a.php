<?php /*?><div id='tpd-banner-ad-a'>   
	<script>
    googletag.cmd.push( function() {
    googletag.display( 'tpd-banner-ad-a' );
    } );
    </script>
</div><?php */?>
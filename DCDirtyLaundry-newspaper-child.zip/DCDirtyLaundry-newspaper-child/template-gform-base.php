<?php /* Template Name: GF Base Template */ ?>
<?php if ( have_posts() ) while ( have_posts() ) : the_post();

// Get Content for variable creation
$content = explode(',', get_the_content());
// Variable Creation
$sitelogo = $content[0];
$bgimage = $content[1];
$gravityform = $content[2];
$colormain = $content[3];
$colorsec = $content[4]; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php echo get_the_title() . ' | ' . get_bloginfo('name'); ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php do_action('wpseo_head'); ?>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Gravity Forms CSS -->
    <link rel='stylesheet' id='gforms_reset_css-css' href='<?php echo get_bloginfo('url'); ?>/wp-content/plugins/gravityforms/css/formreset.min.css' type='text/css' media='all'/>
    <link rel='stylesheet' id='gforms_formsmain_css-css' href='<?php echo get_bloginfo('url'); ?>/wp-content/plugins/gravityforms/css/formsmain.min.css' type='text/css' media='all'/>
    <link rel='stylesheet' id='gforms_ready_class_css-css' href='<?php echo get_bloginfo('url'); ?>/wp-content/plugins/gravityforms/css/readyclass.min.css' type='text/css' media='all'/>
    <link rel='stylesheet' id='gforms_browsers_css-css' href='<?php echo get_bloginfo('url'); ?>/wp-content/plugins/gravityforms/css/browsers.min.css' type='text/css' media='all'/>
    <link rel='stylesheet' id='gpoll_css-css' href='<?php echo get_bloginfo('url'); ?>/wp-content/plugins/gravityformspolls/css/gpoll.css' type='text/css' media='all'/>

    <!-- Page Styles -->
    <style type="text/css">
    body {
        background: url('<?php echo $bgimage; ?>') no-repeat;
        background-size: cover;
        background-position-x: 50%;
    }

    .wpdev-content {
        background: rgba(255, 255, 255, 0.9);
        padding: 1rem 2rem;
        border-radius: 4px;
    }

    .gform_heading, .gfield.poll1 label.gfield_label, ul.gfield_radio li input[type=radio], .gform_wrapper ul.gform_fields li.gfield.gfemail label.gfield_label {
        display: none !important;
        visibility: hidden !important;
    }

    .gfield h1 {
        font-weight: bold;
        text-align: center;
        display: block;
    }

    a {
        transition: all 0.3s ease;
        -webkit-transition: all 0.3s ease;
        -moz-transition: all 0.3s ease;
    }

    a.wpdev-share-btn {
        font-size: 2rem;
        padding: 0.8rem 1rem;
        display: inline-block;
        margin: 0.2rem;
        min-width: 50px;
    }

    a.wpdev-share-btn.wpdev-fb-share {
        color: #3b5998;
    }

    a.wpdev-share-btn.wpdev-tw-share {
        color: #1da1f2;
    }

    a.wpdev-share-btn.wpdev-gp-share {
        color: #dd4b39;
    }

    a.wpdev-share-btn.wpdev-pn-share {
        color: #bd081c;
    }

    a.wpdev-share-btn.wpdev-em-share {
        color: #239ab9;
    }

    a.wpdev-share-btn:hover {
        color: #fff;
    }

    a.wpdev-share-btn.wpdev-fb-share:hover {
        background: #3b5998;
    }

    a.wpdev-share-btn.wpdev-tw-share:hover {
        background: #1da1f2;
    }

    a.wpdev-share-btn.wpdev-gp-share:hover {
        background: #dd4b39;
    }

    a.wpdev-share-btn.wpdev-pn-share:hover {
        background: #bd081c;
    }

    a.wpdev-share-btn.wpdev-em-share:hover {
        background: #239ab9;
    }

    ul.gfield_radio li label {
        font-size: 2rem !important;
        display: block !important;
        padding: 0.8rem 2rem !important;
        border: 2px solid rgba(0, 0, 0, 0.2);
        color: rgba(0, 0, 0, 0.3);
        max-width: 100% !important;
    }

    ul.gfield_radio li label:before {
        content: "✔";
        margin-right: 1rem;
    }

    ul.gfield_radio li label:hover {
        color: <?php echo $colormain; ?>;
    }

    ul.gfield_radio li label.checked {
        color: #fff;
        background: <?php echo $colormain; ?>;
    }

    ul.gfield_radio {
        width: 100% !important;
    }

    .gform_wrapper h3 {
        font-weight: bold;
        text-align: center;
    }

    ul.gfield_radio li label {
        font-size: 2rem !important;
        display: block !important;
        padding: 0.8rem 2rem !important;
        border: 2px solid rgba(0, 0, 0, 0.2);
        color: rgba(0, 0, 0, 0.3);
        max-width: 100% !important;
    }

    ul.gfield_radio li label:before {
        content: "✔";
        margin-right: 1rem;
    }

    ul.gfield_radio li label:hover {
        color: <?php echo $colormain; ?>;
    }

    ul.gfield_radio li label.checked {
        color: #fff;
        background: <?php echo $colormain; ?>;
    }

    ul.gfield_radio {
        width: 100% !important;
    }

    .gform_wrapper h3 {
        font-weight: bold;
        text-align: center;
    }

    li.gfemail label {
        font-size: 2rem !important;
    }

    .ginput_container.ginput_container_email input {
        width: 100% !important;
        display: block !important;
        padding: 1rem !important;
        border: 2px solid rgba(0, 0, 0, 0.3);
    }

    .gform_footer button.button, .gform_footer input.gform_button.button {
        background: <?php echo $colorsec; ?>;
        color: #fff;
        border: 2px solid <?php echo $colormain; ?>;
        font-size: 2rem;
        text-transform: uppercase;
        font-weight: bold;
        display: block;
        width: 100%;
        padding: 1rem;
    }

    .gform_footer button.button:hover, .gform_footer input.gform_button.button:hover {
        border-color: <?php echo $colorsec; ?>;
        background: <?php echo $colormain; ?>;
    }

    .green .gpoll_ratio_box {
        background: <?php echo $colorsec; ?>;
    }

    .green .gpoll_bar_juice {
        background: <?php echo $colormain; ?>;
        background-image: none !important;
    }

    div.gform_confirmation_wrapper  .gpoll_field {
        margin: 2rem 0;
        font-size: 2rem !important;
        font-weight: bold;
    }
        
    .gform_wrapper ul.gform_fields li.gfield {
        padding-right: 0;
    }
        
    .wpdev-content img {
        max-width: 100%;
    }
        
    .wpdev-content {
        margin-top: 40px !important;  
    }
        
    .gform_wrapper .gfield_radio li label {
        margin: 0;
    }
        
    .ginput_container.ginput_container_email input {
        border: 2px solid <?php echo $colormain; ?>;
    }
        
    a.wpdev-back-btn {
        display: block;
        text-align: center;
        color: #fff;
        background: #222;
        padding: 8px;
        text-transform: uppercase;
        font-size: 12px;
        box-shadow: inset 2px 2px 0px rgba(255, 255, 255, 0.1), inset -2px -2px 0px rgba(255, 255, 255, 0.1);
        text-decoration: none;
    }

    .gform_wrapper .gform_footer {
        padding: 16px 0 0 0;
    }
        
    @media only screen and (max-width: 641px) {
        .gform_wrapper ul.gfield_checkbox li label, .gform_wrapper ul.gfield_radio li label {
            width: 99% !important;
        }
    }
        
    @media screen and (max-width: 600px) {
        
        .gform_wrapper ul.gfield_checkbox li label, .gform_wrapper ul.gfield_radio li label {
            width: 99%;
        }

        .wpdev-content {
            margin-top: 20px !important;
        }

        .wpdev-content a img {
            width: 100%;
        }
        
        .wpdev-background {
            height: auto !important;
        }

    }
    </style>

    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      
</head>
  <body>
    <div class="container-fluid wpdev-background">
      <div class="container">
      <div class="row">
          <div class="col-md-6 col-md-offset-3">
            <div class="wpdev-content">
              <!-- Site Logo -->
              <center>
                <a href="<?php echo get_bloginfo('url'); ?>">
                  <img src="<?php echo $sitelogo; ?>" alt="<?php echo get_bloginfo('name'); ?>" />
                </a>
              </center>
              <!-- Form Content -->
              <?php echo do_shortcode('[gravityform id=' . $gravityform . ']'); ?>
              <!-- Back Button -->
              <?php
              // Variables
              parse_str($_SERVER['QUERY_STRING'], $backurlarray);
    
              if(!empty($backurlarray)) {
                  $backurl = $backurlarray['back'];
              } else {
                  $backurl = get_bloginfo('url');
              } ?>
              <a href="<?php echo $backurl; ?>" class="wpdev-back-btn">Go Back</a>
              <!-- Share Buttons -->
              <center>
                <?php
                // Variables
                $url = get_permalink();
                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
                $title = get_the_title();

                $networks = array(
                  'facebook' => array(
                    'icon' => 'fa-facebook',
                    'url' => 'https://www.facebook.com/sharer/sharer.php?u=' . $url,
                    'class' => 'wpdev-fb-share'
                  ),
                  'twitter' => array(
                    'icon' => 'fa-twitter',
                    'url' => 'https://twitter.com/home?status=' . urlencode($title) . ' - Vote Now! - ' . $url,
                    'class' => 'wpdev-tw-share'
                  ),
                  'google' => array(
                    'icon' => 'fa-google-plus',
                    'url' => 'https://plus.google.com/share?url=' . $url,
                    'class' => 'wpdev-gp-share'
                  ),
                  'pinterest' => array(
                    'icon' => 'fa-pinterest',
                    'url' => 'https://pinterest.com/pin/create/button/?url=' . $url . '&media=' . $image[0] . '&description=' . urlencode($title) . ' - Vote Now!',
                    'class' => 'wpdev-pn-share'
                  ),
                  'email' => array(
                    'icon' => 'fa-envelope',
                    'url' => 'mailto:?&subject=' . urlencode('Check out this petition!') . '&body=' . urlencode('Vote now here! - ' . $url),
                    'class' => 'wpdev-em-share'
                  )
                );

                foreach ($networks as $network) {
                  echo '<a href="' . $network['url'] . '" class="wpdev-share-btn ' . $network['class'] . '" target="_blank"><i class="fa ' . $network['icon'] . '"></i></a>';
                } ?>
              </center>
            </div>
          </div>
        </div>
      </div>
    </div><!-- /.container -->

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <!-- Gravity Forms JavaScript -->
    <script type='text/javascript' src='<?php echo get_bloginfo('url'); ?>/wp-content/plugins/gravityforms/js/placeholders.jquery.min.js'></script>

    <?php $siteurl = get_bloginfo('url');
    $sitedomain = preg_replace('/(http.*?\:\/\/)(.*?com)(.*)/', '$2', $siteurl); ?>

    <script type='text/javascript'>
    /* <![CDATA[ */
    var gpollVars = {"ajaxurl":"http:\/\/<?php echo $sitedomain; ?>\/wp-admin\/admin-ajax.php","imagesUrl":"http:\/\/<?php echo $sitedomain; ?>\/wp-content\/plugins\/gravityformspolls\/images"};
    var gpoll_strings = {"viewResults":"View results","backToThePoll":"Back to the poll"};
    /* ]]> */
    </script>

    <script type='text/javascript' src='<?php echo get_bloginfo('url'); ?>/wp-content/plugins/gravityformspolls/js/gpoll.js'></script>

    <!-- FontAwesome -->
    <script type='text/javascript' src='//use.fontawesome.com/2901d4eb55.js'></script>

    <!-- Custom JS -->
    <script type="text/javascript">
    jQuery(document).on('ready', function() {
        var screenHeight = jQuery(window).height();
        var boxHeight = jQuery('.wpdev-content').height();
        var bodyHeight = jQuery('body').height();
        if(bodyHeight < screenHeight && screenHeight > boxHeight) {
            jQuery('body').css('height', screenHeight);
        }
        jQuery(window).resize(function() {
            if(bodyHeight < screenHeight && screenHeight > boxHeight) {
                jQuery('body').css('height', screenHeight);
            }
        });
    });
    jQuery('ul.gfield_radio li label').on('click', function() {
    	jQuery('ul.gfield_radio li label').removeClass('checked');
    	jQuery(this).addClass('checked');
    });
    </script>
  </body>
</html>
<?php endwhile; ?>
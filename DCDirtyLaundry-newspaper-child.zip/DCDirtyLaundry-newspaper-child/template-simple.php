<?php /* Template Name: Simple Template */ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title><?php wp_title(); ?></title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<link href="https://fonts.googleapis.com/css?family=Merriweather:400,400i,900,900i" rel="stylesheet">

<style>body{background:#231b11 -webkit-linear-gradient(top,#382309,#231b11) no-repeat;font-family:Merriweather,serif;font-weight:400;color:#333}.container{max-width:600px;margin:50px auto 0}.entry{padding:10px 20px 20px;border-radius:4px;background:#fff}.h1,h1{font-size:2rem;margin:10px 0 20px;font-weight:900}img{max-width:100%}.logo{max-width:350px;margin:0 auto 10px;display:block}input{float:left;height:20px;width:50%;padding:14px 8px}button{height:32px;width:100px;float:left}button:hover{background:-webkit-gradient(linear,left top,left bottom,from(#e2e2e2),to(#cacaca));background:-webkit-linear-gradient(top,#e2e2e2,#cacaca)}p{clear:both}iframe{max-width:100%}</style>
	</head>
	<body>
		<div class="container">
			<a href="/" class="logo"><img src="/wp-content/uploads/2018/07/gar-logo-new3.png"></a>
			<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
			<div class="entry">
	            <h1 class="main_title"><?php the_title(); ?></h1>
				<?php the_content(); ?>
				<div style="clear:both;"></div>		
			</div>
			<?php endwhile; ?>
            <?php edit_post_link('edit', '<p style="text-align:right;">', '</p>'); ?>
		</div>
        
	</body>
</html>
<?php /*?><div class="tpd-banner-ad-b">
<div id="rcjsload_1513dc"></div>
<script type="text/javascript">
(function() {
var referer="";try{if(referer=document.referrer,"undefined"==typeof referer||""==referer)throw"undefined"}catch(exception){referer=document.location.href,(""==referer||"undefined"==typeof referer)&&(referer=document.URL)}referer=referer.substr(0,700);
var rcds = document.getElementById("rcjsload_1513dc");
var rcel = document.createElement("script");
rcel.id = 'rc_' + Math.floor(Math.random() * 1000);
rcel.type = 'text/javascript';
rcel.src = "https://trends.revcontent.com/serve.js.php?w=106601&t="+rcel.id+"&c="+(new Date()).getTime()+"&width="+(window.outerWidth || document.documentElement.clientWidth)+"&referer="+encodeURIComponent(referer);
rcel.async = true;
rcds.appendChild(rcel);
})();
</script>
</div><?php */?>
<div class='tpd-box-ad-d tpd-box-ad-e'>
	<!-- dcDirtyLaundry.com-336x280-5 -->
	<ins class="adsbygoogle"
		 style="display:inline-block;width:336px;height:280px"
		 data-ad-client="ca-pub-3121246872096424"
		 data-ad-slot="3589059718"></ins>
	<script>
	(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
</div>
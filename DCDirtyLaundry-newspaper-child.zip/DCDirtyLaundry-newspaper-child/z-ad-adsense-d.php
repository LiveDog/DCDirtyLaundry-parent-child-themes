<div class='tpd-box-ad-d'>
	<!-- dcDirtyLaundry.com-336x280-4 -->
	<ins class="adsbygoogle"
		 style="display:inline-block;width:336px;height:280px"
		 data-ad-client="ca-pub-3121246872096424"
		 data-ad-slot="2327948934"></ins>
	<script>
	(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
</div>
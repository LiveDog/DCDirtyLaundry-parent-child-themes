<div class="z-contextual-ad-c">
	<div id='tpd-contextual-ad-c'>
		<div id="taboola-right-rail-thumbnails-2"></div>
		<script type="text/javascript">
		if (TPD_Mobile == false) {
		window._taboola = window._taboola || [];
		_taboola.push({
				device: TPD_ContextualAd_C_Tab_device,
				mode: TPD_ContextualAd_C_Tab_mode,
				container: TPD_ContextualAd_C_Tab_container,
				placement: TPD_ContextualAd_C_Tab_placement,
				target_type: TPD_ContextualAd_C_Tab_targettype
		});
		}
		</script>
	</div>
</div>
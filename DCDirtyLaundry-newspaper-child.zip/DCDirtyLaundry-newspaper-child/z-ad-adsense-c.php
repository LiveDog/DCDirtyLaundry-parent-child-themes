<div class='tpd-box-ad-c'>
	<!-- dcDirtyLaundry.com-336x280-3 -->
	<ins class="adsbygoogle"
		 style="display:inline-block;width:336px;height:280px"
		 data-ad-client="ca-pub-3121246872096424"
		 data-ad-slot="7771847307"></ins>
	<script>
	(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
</div>
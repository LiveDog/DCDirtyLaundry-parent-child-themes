<div class='tpd-box-ad-c'>
	<div id='tpd-box-ad-c'>   
		<script type='text/javascript'>
		googletag.cmd.push( function() {
		googletag.display( 'tpd-box-ad-c' );
		} );
		</script>
	</div>
</div>
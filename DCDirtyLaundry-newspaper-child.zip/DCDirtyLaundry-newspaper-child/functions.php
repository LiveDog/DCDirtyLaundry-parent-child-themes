<?php

add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles', 999 );
function theme_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    //wp_enqueue_style( 'z-custom-css', get_stylesheet_directory_uri() . '/z-custom.css' );
    //wp_enqueue_style( 'z-custom-media-queries-css', get_stylesheet_directory_uri() . '/z-custom-media-queries.css' );
}

// Function to remove version numbers from styles and scripts	
add_filter( 'style_loader_src', 'sdt_remove_ver_css_js', 9999 );
add_filter( 'script_loader_src', 'sdt_remove_ver_css_js', 9999 );
function sdt_remove_ver_css_js( $src ) {
	if ( strpos( $src, 'ver=' ) )
		$src = remove_query_arg( 'ver', $src );
	return $src;
}

/* Fix Cropped Images */
function wpdev_thumbnail_crop_fix( $default, $orig_w, $orig_h, $new_w, $new_h, $crop ){
    if ( !$crop ) return null; // let the wordpress default function handle this
    $aspect_ratio = $orig_w / $orig_h;
    $size_ratio = max($new_w / $orig_w, $new_h / $orig_h);
    $crop_w = round($new_w / $size_ratio);
    $crop_h = round($new_h / $size_ratio);
    $s_x = floor( ($orig_w - $crop_w) / 2 );
    $s_y = floor( ($orig_h - $crop_h) / 2 );
    return array( 0, 0, (int) $s_x, (int) $s_y, (int) $new_w, (int) $new_h, (int) $crop_w, (int) $crop_h );
}
add_filter( 'image_resize_dimensions', 'wpdev_thumbnail_crop_fix', 10, 6 );

/** Add Facebook Image Size and Specify OG:IMAGE Tag **/
add_image_size('facebook', 1200, 630, true);
function klicked_image_check() {
    if(is_single()) {
        $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
        if($image[1] === 1200 && $image[2] === 630) {
        } else {
            add_filter('wpseo_opengraph_image_size', 'klicked_wpseo_image_size', 10, 1);
        }
    }
}
add_action('wp', 'klicked_image_check');
function klicked_wpseo_image_size() {
    return 'facebook';
}

/* Create Sidebar for Homepage */
register_nav_menus( array(
	'header-menu-second' => 'Secondary Header Menu',
) );
function custom_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Homepage Sidebar', 'textdomain' ),
        'id'            => 'tw-sidebar',
        'description'   => __( '', 'textdomain' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s twt">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="block-title">',
        'after_title'   => '</h4>',
    ) );
}
add_action( 'widgets_init', 'custom_widgets_init' );
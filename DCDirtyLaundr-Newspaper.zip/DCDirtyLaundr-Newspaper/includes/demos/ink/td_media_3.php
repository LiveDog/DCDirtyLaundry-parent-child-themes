<?php


td_demo_media::add_image_to_media_gallery('home_booking',               'http://demo_content.tagdiv.com/Newspaper_multi/ink/home_booking.jpg');

//the artists page
td_demo_media::add_image_to_media_gallery('artist1',                    'http://demo_content.tagdiv.com/Newspaper_multi/ink/artist1.jpg');
td_demo_media::add_image_to_media_gallery('artist2',                    'http://demo_content.tagdiv.com/Newspaper_multi/ink/artist2.jpg');
td_demo_media::add_image_to_media_gallery('artist3',                    'http://demo_content.tagdiv.com/Newspaper_multi/ink/artist3.jpg');

td_demo_media::add_image_to_media_gallery('team_tattoos1',              'http://demo_content.tagdiv.com/Newspaper_multi/ink/team_tattoos1.jpg');